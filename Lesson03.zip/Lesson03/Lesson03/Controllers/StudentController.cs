﻿using Microsoft.AspNetCore.Mvc;

namespace Lesson03.Controllers
{
    public class StudentController : Controller
    {
        //Action
        //Routing with Attribute
        [Route("attribute/student/index")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
