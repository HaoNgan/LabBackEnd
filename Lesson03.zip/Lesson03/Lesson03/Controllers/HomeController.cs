using System.Diagnostics;
using Lesson03.Models;
using Microsoft.AspNetCore.Mvc;

namespace Lesson03.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private NotificationService _notificationService;

        public HomeController(ILogger<HomeController> logger, NotificationService notificationService)//Constructor Injection
        {
            _logger = logger;
            _notificationService = notificationService;
        }

        public IActionResult Index()
        {
            //NotificationService emailService = new NotificationService(new EmailService());
            //emailService.SenNotification("Hello");
            //NotificationService smsService = new NotificationService(new SmsService());
            //smsService.SenNotification("Hi");
            //NotificationService zaloService = new NotificationService(new ZaloService());
            //zaloService.SenNotification("Chao");

            _notificationService.SenNotification("Hello");
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
