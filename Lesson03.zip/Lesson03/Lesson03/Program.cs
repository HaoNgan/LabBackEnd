﻿using Lesson03.Models;

var builder = WebApplication.CreateBuilder(args);

// Thêm dịch vụ MVC (Controller + View)
builder.Services.AddControllersWithViews();

// Đăng ký các dịch vụ vào DI Container
// 3 loại vòng đời:
// - Transient: AddTransient()
// - Scoped: AddScoped()
// - Singleton: AddSingleton()
builder.Services.AddScoped<INotificationChannel, EmailService>();
builder.Services.AddScoped<NotificationService>();

var app = builder.Build();

// Sử dụng Custom Middleware (LoggingMiddleware)
app.UseMiddleware<LoggingMiddleware>();

// Cấu hình pipeline xử lý lỗi
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

// Cho phép sử dụng các file tĩnh trong wwwroot
app.UseStaticFiles();

// Thiết lập Routing
app.UseRouting();

// Thiết lập phân quyền (authorization)
app.UseAuthorization();

// Cấu hình định tuyến mặc định
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Khởi động ứng dụng
app.Run();
