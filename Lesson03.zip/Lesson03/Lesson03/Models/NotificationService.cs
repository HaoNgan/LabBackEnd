﻿namespace Lesson03.Models
{
    public class NotificationService
    {
        public INotificationChannel _channel;
        //Constructor Injection
        public NotificationService(INotificationChannel channel)
        {
            _channel = channel;
        }
        public void SenNotification(string message)
        {
            _channel.Send(message);
        }
    }
}
