﻿using System;

namespace Lesson03.Models
{
    public interface INotificationChannel
    {
        public void Send(string message);
    }

    public class EmailService : INotificationChannel
    {
        public void Send(string message)
        {
            Console.WriteLine($"Send Email: {message}");
        }
    }
    public class SmsService : INotificationChannel
    {
        public void Send(string message)
        {
            Console.WriteLine($"Send SMS: {message}");
        }
    }
    public class ZaloService : INotificationChannel
    {
        public void Send(string message)
        {
            Console.WriteLine($"Send Zalo: {message}");
        }
    }
}
