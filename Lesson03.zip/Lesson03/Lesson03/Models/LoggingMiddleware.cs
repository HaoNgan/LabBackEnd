﻿using System.Threading.Tasks;
using System;

namespace Lesson03.Models
{
    public class LoggingMiddleware
    {
        private readonly RequestDelegate _next;
        public LoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            //Xử lí logic trước khi chuyển sang Middleware tiếp theo
            Console.WriteLine("Logging Middleware Started...");
            //Chuyển sang Middleware tiếp theo
            await _next(context);
            //Xử lí logic sau khi Middleware sau nó thực thi xong
            Console.WriteLine("Logging Middleware End!");
        }
    }
}
namespace Lesson03.Models
{
    public class LoggingMiddleware
    {
        private readonly RequestDelegate _next;
        public LoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            //Xử lí logic trước khi chuyển sang Middleware tiếp theo
            Console.WriteLine("Logging Middleware Started...");
            //Chuyển sang Middleware tiếp theo
            await _next(context);
            //Xử lí logic sau khi Middleware sau nó thực thi xong
            Console.WriteLine("Logging Middleware End!");
        }
    }
}
