﻿using System;
using System.Text;

namespace Lab04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.Write("Nhập một số nguyên: ");
            int num = int.Parse(Console.ReadLine());

            NumberChecker checker = new NumberChecker();

            if (checker.IsEven(num))
            {
                Console.WriteLine($"{num} là số chẵn.");
            }
            else
            {
                Console.WriteLine($"{num} là số lẻ.");
            }
        }
    }
}
