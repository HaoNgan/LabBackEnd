﻿namespace Lab04
{
    internal class NumberChecker
    {
        // Hàm kiểm tra số chẵn
        public bool IsEven(int number)
        {
            return number % 2 == 0;
        }
    }
}
