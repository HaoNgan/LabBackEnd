﻿using System;

namespace Lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;

            Console.Write("Nhap so de khiem tra: ");
            bool isValid = int.TryParse(Console.ReadLine(), out number);

            // Kiểm tra nếu đầu vào hợp lệ
            if (!isValid)
            {
                Console.WriteLine("Nhap so hop le! ");
            }
            else
            {
                // Kiểm tra số nguyên tố
                if (IsPrime(number))
                {
                    Console.WriteLine(number + " la so nguyen to.");
                }
                else
                {
                    Console.WriteLine(number + " Khong la so nguyen to.");
                }
            }
        }

        static bool IsPrime(int num)
        {
            if (num <= 1) return false; 
            for (int i = 2; i < num; i++) 
            {
                if (num % i == 0) 
                {
                    return false;
                }
            }
            return true; 
        }
    }
}
