﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int bang = 1;

        while (bang <= 10)
        {
            Console.WriteLine("Bảng nhân " + bang);

            int so = 1;
            while (so <= 10)
            {
                int ketQua = bang * so;

                Console.WriteLine(bang + " x " + so + " = " + ketQua);

                so++; 
            }

            Console.WriteLine(); 
            bang++; 
        }
    }
}
