﻿using System;

namespace lab09
{
    class Program 
    {
        static void Main(string[] args)
        {
            MayTinhGiaiThua mayTinh = new MayTinhGiaiThua();

            Console.Write("Nhap so nguyen duong");
            int soNhap = int.Parse(Console.ReadLine());

            if (soNhap < 0)
            {
                Console.WriteLine("Vui long nhap so nguyen duong");
            }
            else
            {
                // Tính giai thừa
                long ketQua = mayTinh.TinhGiaiThua(soNhap);

                Console.WriteLine($"{soNhap}! = {ketQua}");
            }

            Console.WriteLine("Ket thuc chuong trinh");
        }
    }
}
