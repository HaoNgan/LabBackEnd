﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace lab09
{
    // Lớp Máy Tính Giai Thừa
    public class MayTinhGiaiThua
    {
        // Phương thức tính giai thừa
        public long TinhGiaiThua(int so)
        {
            long ketQua = 1;

            for (int i = 1; i <= so; i++)
            {
                ketQua *= i;
            }

            return ketQua;
        }
    }
}

