﻿using System;
using System.Text;

namespace Lab06
{
    class Program
    {
        static void Main(string[] args)
        {
            // Cấu hình để hiển thị tiếng Việt trong Console
            Console.OutputEncoding = Encoding.UTF8;

            // Khai báo biến
            double number;

            // Nhập số từ bàn phím
            Console.Write("Nhập một số bất kỳ: ");
            number = double.Parse(Console.ReadLine());

            // Kiểm tra số dương, âm hay bằng 0
            if (number > 0)
            {
                Console.WriteLine($"{number} là số dương.");
            }
            else if (number < 0)
            {
                Console.WriteLine($"{number} là số âm.");
            }
            else
            {
                Console.WriteLine("Đây là số không (0).");
            }
        }
    }
}
