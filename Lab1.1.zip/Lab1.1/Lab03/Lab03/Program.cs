﻿using System;
using System.Text;

namespace Lap03
{
    class Program
    {
        static void Main(string[] args)
        {
            // Đảm bảo rằng Console sẽ hiển thị tiếng Việt đúng
            Console.OutputEncoding = Encoding.UTF8;

            // Khai báo biến để lưu trữ giá trị nhiệt độ (độ C) và kết quả (độ F)
            double celsius, fahrenheit;

            // Yêu cầu người dùng nhập nhiệt độ theo đơn vị độ C
            Console.WriteLine("Nhập nhiệt độ (độ C):");
            Console.Write("- C: ");
            celsius = double.Parse(Console.ReadLine()); // Lấy giá trị nhập từ người dùng

            // Sử dụng công thức để chuyển đổi từ độ C sang độ F
            // Công thức: F = (C * 9/5) + 32
            fahrenheit = (celsius * 9 / 5) + 32;

            // In kết quả chuyển đổi ra màn hình
            Console.WriteLine($"{celsius} độ C bằng {fahrenheit} độ F.");
        }
    }
}
