﻿using System;
using System.Text;

namespace Lab07
{
    class Program
    {
        // Lớp KiểmTraNamNhuan dùng để kiểm tra xem năm có phải là năm nhuận hay không
        public class KiemTraNamNhuan
        {
            // Phương thức kiểm tra năm nhuận
            public bool IsLeapYear(int nam)
            {
                // Kiểm tra điều kiện năm nhuận:
                // Năm chia hết cho 4 và không chia hết cho 100, hoặc chia hết cho 400
                return (nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0);
            }
        }

        static void Main(string[] args)
        {
            // Cấu hình để hiển thị tiếng Việt trong Console
            Console.OutputEncoding = Encoding.UTF8;

            // Khai báo biến để lưu năm nhập vào
            int nam;

            // Nhập năm từ người dùng
            Console.Write("Nhập năm cần kiểm tra: ");
            nam = int.Parse(Console.ReadLine());

            // Tạo đối tượng của lớp KiemTraNamNhuan để kiểm tra năm
            KiemTraNamNhuan kiemTra = new KiemTraNamNhuan();

            // Kiểm tra năm nhuận và hiển thị kết quả
            if (kiemTra.IsLeapYear(nam))
            {
                Console.WriteLine($"{nam} là năm nhuận.");
            }
            else
            {
                Console.WriteLine($"{nam} không phải là năm nhuận.");
            }
        }
    }
}
