﻿using System;
using System.Text;

namespace Lab05
{
    class Program
    {
        static void Main(string[] args)
        {
            // Cấu hình để hiển thị tiếng Việt trong cửa sổ Console
            Console.OutputEncoding = Encoding.UTF8;

            // Khai báo hai biến số thực để lưu giá trị nhập vào
            double a, b;

            // Nhập số thứ nhất từ bàn phím
            Console.Write("Nhập số thứ nhất: ");
            a = double.Parse(Console.ReadLine());

            // Nhập số thứ hai từ bàn phím
            Console.Write("Nhập số thứ hai: ");
            b = double.Parse(Console.ReadLine());

            // Tạo đối tượng của lớp MayTinh
            MayTinh mayTinh = new MayTinh();

            // Gọi hàm tính tổng và tích
            double tong = mayTinh.TinhTong(a, b);
            double tich = mayTinh.TinhTich(a, b);

            // Hiển thị kết quả ra màn hình
            Console.WriteLine($"\nTổng của {a} và {b} là: {tong}");
            Console.WriteLine($"Tích của {a} và {b} là: {tich}");
        }
    }
}
