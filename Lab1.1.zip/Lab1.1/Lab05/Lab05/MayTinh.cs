﻿namespace Lab05
{
    // Lớp MayTinh dùng để xử lý các phép toán như cộng và nhân
    public class MayTinh
    {
        // Hàm tính tổng của hai số
        public double TinhTong(double a, double b)
        {
            return a + b;
        }

        // Hàm tính tích của hai số
        public double TinhTich(double a, double b)
        {
            return a * b;
        }
    }
}
