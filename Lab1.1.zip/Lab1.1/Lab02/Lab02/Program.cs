﻿using System;
using System.Text;

namespace Lab02
{
    class Program
    {
        static void Main(string[] args)
        {
            // Cấu hình hiển thị tiếng Việt trong Console
            Console.OutputEncoding = Encoding.UTF8;

            // 1. Khai báo biến
            double chieuDai, chieuRong;

            // 2. Nhập chiều dài
            Console.Write("Nhập chiều dài: ");
            chieuDai = double.Parse(Console.ReadLine());

            // 3. Nhập chiều rộng
            Console.Write("Nhập chiều rộng: ");
            chieuRong = double.Parse(Console.ReadLine());

            // 4. Tính diện tích (công thức: dài * rộng)
            double dienTich = chieuDai * chieuRong;

            // 5. Hiển thị kết quả
            Console.WriteLine($"Diện tích hình chữ nhật là: {dienTich}");
        }
    }
}
